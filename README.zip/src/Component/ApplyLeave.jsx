import React from "react";
import axios from "axios";
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

class Applyleave extends React.Component{
    constructor(){
        super();
        this.state={
            numberOfDays:'',
            startDate:'',
            endDate:'',
            leaveType:'',
            leaveReason:''

        }
    }
    changeNumberOfDaysHandler=(event)=>
    {
        this.setState({numberOfDays:event.target.value})
    }
    changeStartDateHandler=(event)=>
    {
        this.setState({startDate:event.target.value})
    }
    changeEndDateHandler=(event)=>
    {
        this.setState({endDate:event.target.value})
    }
    changeLeaveTypeHandler=(event)=>
    {
        this.setState({leaveType:event.target.value})
    }
    changeLeaveReasonHandler=(event)=>
    {
        this.setState({leaveReason:event.target.value})
    }
    saveLeave=(e)=>
    {
        e.preventDefault();
        console.log('Save Leave method called')
        console.log(this.state.numberOfDays,this.state.startDate,this.state.endDate,this.state.leaveType,this.state.leaveReason)
        const result=axios.post("http://localhost:49650/api/LeaveApplications",
        {
            "LeaveApplicationId":0,
            "NumberOfDays":this.state.numberOfDays,
            "StartDate":this.state.startDate,
            "EndDate":this.state.endDate,
            "LeaveType":this.state.leaveType,
            "LeaveReason":this.state.leaveReason,
            "EmployeeId":localStorage.getItem('Id')
            
        });
        console.log(result)
    }
    render(){
        return(
            <Card className='BgColor-Card'>
            <CardContent>
            <div className="container">
                <div className="card-body">
                    <form>
                        <div className="form-group">
                            <label>NumberOfDays</label>
                            <input className="form-control" name="noofdays"
                            onChange={this.changeNumberOfDaysHandler}
                            value={this.state.numberOfDays}/>
                        </div>
                        <div className="form-group">
                            <label>StartDate</label>
                            <input className="form-control" name="startdate"
                            onChange={this.changeStartDateHandler}
                            value={this.state.startDate}/>
                        </div>
                        <div className="form-group">
                            <label>EndDate</label>
                            <input className="form-control" name="enddate"
                            onChange={this.changeEndDateHandler}
                            value={this.state.endDate}/>
                        </div>
                        <div className="form-group">
                            <label>LeaveType</label>
                            <input className="form-control" name="leavetype"
                            onChange={this.changeLeaveTypeHandler}
                            value={this.state.leaveType}/>
                        </div>
                        <div className="form-group">
                            <label>Leave Reason</label>
                            <input className="form-control" name="leavereason"
                            onChange={this.changeLeaveReasonHandler}
                            value={this.state.leaveReason}/>
                        </div>
                        <button className="btn btn-success" onClick={this.saveLeave}>Apply</button>
                    
                    </form>
                </div>
            </div>
            </CardContent>
            </Card>
           
        )
    }
   

}
export default Applyleave;